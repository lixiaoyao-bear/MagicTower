create definer = root@localhost event create_pos_inout_info_event on schedule
  every '30' MINUTE
    starts '2018-07-01 23:40:00'
  enable
  comment '每半小时执行一次'
  do
  BEGIN
CALL create_pos_inout_info_every_halfhour();
END;

