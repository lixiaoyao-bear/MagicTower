create definer = root@localhost event create_pos_sum_info_event on schedule
  every '1' HOUR
    starts '2019-05-17 17:20:00'
  enable
  comment '每小时执行一次'
  do
  BEGIN
CALL create_pos_sum_info_every_hour();
END;

