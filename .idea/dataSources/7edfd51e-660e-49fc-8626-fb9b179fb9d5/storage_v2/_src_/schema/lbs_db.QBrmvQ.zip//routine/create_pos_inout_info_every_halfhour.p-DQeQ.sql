create
  definer = root@localhost procedure create_pos_inout_info_every_halfhour()
BEGIN
DECLARE bgID INT DEFAULT 0;
DECLARE i0 INT DEFAULT 0;
DECLARE i1 INT DEFAULT 0;
DECLARE i2 INT DEFAULT 1;
DECLARE NUM0 INT DEFAULT 0;
DECLARE NUM1 INT DEFAULT 0;
DECLARE NUM2 INT DEFAULT 0;
DECLARE flag0 INT DEFAULT -1;
DECLARE flag1 INT DEFAULT -1;
DECLARE flag2 INT DEFAULT -1;
DECLARE time1 DATETIME;
DECLARE time2 DATETIME;
DECLARE con VARCHAR(10000);
DECLARE mapNUM INT DEFAULT 0;
DECLARE inoutFlag INT DEFAULT -1;
DECLARE outMapId INT DEFAULT -1;
DECLARE inMapId INT DEFAULT -1;

SET @suffix = DATE_FORMAT(NOW(),'%Y%m01');

DROP TABLE IF EXISTS `temp_bg_list`;
CREATE TEMPORARY TABLE `temp_bg_list`
	(`id` int NOT NULL AUTO_INCREMENT,
	`BG_ID` int,
	PRIMARY KEY(id))
	AUTO_INCREMENT=1;
SET @sqlstr0 = CONCAT("INSERT INTO `temp_bg_list`(BG_ID) SELECT a.DEVICE_ID FROM `",@suffix,"_div_event_list` a,`op_bg_match` b,`operator_info_list` c WHERE a.SDATE BETWEEN DATE_SUB(NOW(),INTERVAL 40 MINUTE) AND NOW() AND a.DEVICE_ID = b.BG_ID AND b.STATUS=1 AND b.STAFF_ID = c.STAFF_ID AND c.CATEGORY = 1 GROUP BY a.DEVICE_ID ORDER BY a.DEVICE_ID ASC;");
PREPARE stmt0 FROM @sqlstr0;
EXECUTE stmt0;
DEALLOCATE PREPARE stmt0;
SELECT COUNT(*) FROM `temp_bg_list` INTO NUM0;

inout_loop0: LOOP
	SET i0 = i0 + 1;
    IF i0 > NUM0 THEN
		LEAVE inout_loop0;
	END IF;
    SELECT BG_ID INTO bgID FROM `temp_bg_list` WHERE id = i0;
	
	DROP TABLE IF EXISTS `temp_div_event`;
	CREATE TEMPORARY TABLE `temp_div_event`
        (`id` int NOT NULL AUTO_INCREMENT,
         `BG_ID` int,
         `INOUT_FLAG` int,
         `STAFF_ID` CHARACTER(60),
         `STAFF_NAME` CHARACTER(60),
         `INOUT_TIME` DATETIME,
         PRIMARY KEY(id))
         COLLATE='utf8_general_ci'
         ENGINE=InnoDB
         AUTO_INCREMENT=1;
	SET @sqlstr1 = CONCAT("INSERT INTO `temp_div_event`(BG_ID,INOUT_FLAG,STAFF_ID,STAFF_NAME,INOUT_TIME) SELECT a.DEVICE_ID AS `BG_ID`,a.STATUS AS `INOUT_FLAG`,obm.STAFF_ID AS `STAFF_ID`,oil.NAME AS `STAFF_NAME`,a.SDATE AS `INOUT_TIME` FROM ( SELECT * FROM `",@suffix,"_div_event_list` WHERE ( SDATE BETWEEN DATE_SUB(NOW(),INTERVAL 40 MINUTE) AND NOW() AND DEVICE_ID =",bgID," )  ) a INNER JOIN op_bg_match obm ON a.DEVICE_ID = obm.BG_ID INNER JOIN operator_info_list oil ON obm.STAFF_ID = oil.STAFF_ID  WHERE obm.STATUS = 1 ORDER BY a.SDATE ASC,a.DIV_EVENT_ID;");
	PREPARE stmt1 FROM @sqlstr1;
	EXECUTE stmt1;
	DEALLOCATE PREPARE stmt1;
    
   SELECT COUNT(*) FROM `temp_div_event` INTO NUM1;
	SELECT `INOUT_FLAG` FROM `temp_div_event` WHERE `id` = 1 INTO flag0;
	SET i1 = 0;
	inout_loop1: LOOP
		SET i1 = i1 + 1;
		IF i1 > NUM1 THEN
			LEAVE inout_loop1;
		END IF;
		SET flag1 = -1;
		SET flag2 = -1;
		SET time1 = null;
		SET time2 = null;
		SELECT `INOUT_FLAG`,`INOUT_TIME` FROM `temp_div_event` WHERE `id` = i1 INTO flag1,time1;
		IF (flag1 = 1) THEN
        	IF (i1 = 1 && TIMESTAMPDIFF(minute,time1,NOW()) > 30) THEN
				ITERATE inout_loop1;
        	ELSEIF (i1 > 1) THEN
				SELECT `INOUT_FLAG`,`INOUT_TIME` FROM `temp_div_event` WHERE `id` = (i1-1) INTO flag2,time2;
				IF ((flag2 = 0 && TIMESTAMPDIFF(minute,time2,time1) < 5) || flag2 = 1)
				THEN
					ITERATE inout_loop1;
				END IF;
         END IF;
			SET con = CONCAT("a.STATUS IN (-",flag1,",",flag1,") AND a.SDATE BETWEEN DATE_SUB('",time1,"', INTERVAL 15 SECOND) AND DATE_ADD('",time1,"', INTERVAL 15 SECOND)");

			DROP TABLE IF EXISTS `temp_map_ids`;
			CREATE TEMPORARY TABLE `temp_map_ids`
			(`id` int NOT NULL AUTO_INCREMENT,
			`time` TIMESTAMP,
			`status` int,
			`mapId` int NOT NULL,
			PRIMARY KEY(id));
			SET @sqlstr2 = CONCAT("INSERT INTO `temp_map_ids`(`time`,`status`,`mapId`) SELECT a.SDATE,a.STATUS,a.MAP_ID FROM (SELECT SDATE,STATUS,MAP_ID FROM `",@suffix,"_pos_event_list` WHERE ( SDATE BETWEEN DATE_SUB(NOW(),INTERVAL 40 MINUTE) AND NOW() AND BG_ID =",bgID," )) a WHERE (",con,") GROUP BY a.MAP_ID ORDER BY a.SDATE ASC;");
			PREPARE stmt2 FROM @sqlstr2;
			EXECUTE stmt2;
			DEALLOCATE PREPARE stmt2;
			SELECT COUNT(*) FROM `temp_map_ids` INTO mapNUM;
			SELECT `mapId` INTO outMapId FROM `temp_map_ids` WHERE `id`=1;
		ELSEIF (flag1 = 0) THEN
        	IF (i1 < NUM1) THEN
				SELECT `INOUT_FLAG`,`INOUT_TIME` FROM `temp_div_event` WHERE `id` = (i1+1) INTO flag2,time2;
				IF ((flag2 = 1 && TIMESTAMPDIFF(minute,time1,time2) < 5) || flag2 = 0)
				THEN
					ITERATE inout_loop1;
				END IF;
         ELSEIF (TIMESTAMPDIFF(minute,time1,NOW()) < 5)
         THEN
					ITERATE inout_loop1;
			END IF;
			SET con = CONCAT("a.STATUS = 0 AND a.SDATE BETWEEN DATE_SUB('",time1,"', INTERVAL 15 SECOND) AND DATE_ADD('",time1,"', INTERVAL 15 SECOND)");
		ELSE
			ITERATE inout_loop1;
		END IF;
        
      DROP TABLE IF EXISTS `temp_pos_inout`;
		CREATE TEMPORARY TABLE `temp_pos_inout`
		(`id` int NOT NULL AUTO_INCREMENT,
		`BG_ID` int,
		`INOUT_FLAG` int,
		`INOUT_TIME` DATETIME,
		`MAP_ID` int,
		`MAP_NAME` CHARACTER(60),
		`LOCATION_NAME` CHARACTER(100),
		PRIMARY KEY(id))
		COLLATE='utf8_general_ci'
		ENGINE=InnoDB
		AUTO_INCREMENT=1;
		SET @sqlstr3 = CONCAT("INSERT INTO `temp_pos_inout`(BG_ID,INOUT_FLAG,INOUT_TIME,MAP_ID,MAP_NAME,LOCATION_NAME) SELECT a.BG_ID,a.STATUS AS INOUT_FLAG,a.SDATE AS INOUT_TIME,a.MAP_ID,b.NAME AS MAP_NAME,c.NAME AS LOCATION_NAME FROM ( SELECT BG_ID,SDATE,STATUS,MAP_ID,KEEP_MS FROM `",@suffix,"_pos_event_list` WHERE ( SDATE BETWEEN DATE_SUB(NOW(),INTERVAL 40 MINUTE) AND NOW() AND BG_ID =",bgID," )) a INNER JOIN map_list b ON a.MAP_ID = b.MAP_ID INNER JOIN location_list c ON c.LOCATION_ID = b.LOCATION_ID WHERE (",con,") ORDER BY a.SDATE ASC;");
		PREPARE stmt3 FROM @sqlstr3;
		EXECUTE stmt3;
		DEALLOCATE PREPARE stmt3;
		UPDATE `temp_pos_inout` SET `INOUT_FLAG`=1 WHERE `INOUT_FLAG`=-1;

      SET @sqlstr4 = CONCAT("INSERT INTO `",@suffix,"_pos_inout_list`( BG_ID,STAFF_ID,NAME,WORK_ASSIGNMENT,BU_ID,ORG_ID,ATTENDANCE_DATE_ID,CLASS_ID,CLASS_NAME,INOUT_FLAG,INOUT_TIME,MAP_ID,BUILDING_NAME,MAP_NAME) SELECT * FROM (SELECT a.BG_ID,b.STAFF_ID,c.NAME,c.WORK_ASSIGNMENT,c.BU_ID,c.ORG_ID,c.ATTENDANCE_DATE_ID,c.CLASS_ID,d.NAME AS CLASS_NAME, a.INOUT_FLAG,a.INOUT_TIME,a.MAP_ID,a.LOCATION_NAME AS BUILDING_NAME,a.MAP_NAME FROM `temp_pos_inout` a,`op_bg_match` b,`operator_info_list` c,`class_shift_test` d WHERE ( a.BG_ID = b.BG_ID AND b.STATUS = 1 AND b.STAFF_ID = c.STAFF_ID AND c.CLASS_ID = d.CLASS_ID) LIMIT 1) AS tb;");
      PREPARE stmt4 FROM @sqlstr4;
      EXECUTE stmt4;
      DEALLOCATE PREPARE stmt4;
	END LOOP;
END LOOP;

SET @sqlstr5 = CONCAT("DELETE FROM `",@suffix,"_pos_inout_list` WHERE INOUT_TIME BETWEEN DATE_SUB(NOW(),INTERVAL 40 MINUTE) AND NOW() AND `POS_INOUT_ID` IN (select * from (SELECT `POS_INOUT_ID` FROM `",@suffix,"_pos_inout_list` GROUP BY `BG_ID`,`INOUT_TIME`,`INOUT_FLAG` HAVING COUNT(`INOUT_FLAG`) >1)b);");
PREPARE stmt5 FROM @sqlstr5;
EXECUTE stmt5;
END;

