create definer = root@localhost event create_pos_inout_tables_event on schedule
  every '1' MONTH
    starts '2018-07-01 00:00:00'
  enable
  comment '每个月执行一次'
  do
  BEGIN
CALL create_pos_inout_table_every_mon();
END;

